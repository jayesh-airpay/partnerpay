$(document).ready(function() {
	
	
	$('input[type=file]').bootstrapFileInput();
	$('.file-inputs').bootstrapFileInput();
	$('#utSelect').prop('selectedIndex', -1);
	$('#utSelect2').prop('selectedIndex', -1);

	
}); // (jQuery)End of use strict
