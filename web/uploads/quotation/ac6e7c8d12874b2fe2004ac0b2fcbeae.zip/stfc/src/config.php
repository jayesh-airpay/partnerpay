<?php
/**
 * Created by PhpStorm.
 * User: akshay
 * Date: 10/2/15
 * Time: 11:40 AM
 */
return array(
    'rootLogger' => array(
        'appenders' => array('default'),
    ),
    'appenders' => array(
        'default' => array(
            'class' => 'LoggerAppenderFile',
            'layout' => array(
                'class' => 'LoggerLayoutPattern',
                'params' => array(
                    'conversionPattern' => '%date [%pid] %logger %-5level  Message: %msg%n'
                )
            ),
            'params' => array(
                'file' => dirname(__FILE__).'/../runtime/data.log',
                'append' => true
            )
        )
    )
);