<?php

namespace app\controllers;

use app\models\ImportPO;
use Yii;
use app\models\PoMaster;
use app\models\PoMasterSearch;
use yii\base\Hcontroller;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

/**
 * PoController implements the CRUD actions for PoMaster model.
 */
class PoController extends Hcontroller
{
    public function behaviors()
    {
        /*return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];*/
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['index','update','create','view','import'],
                'rules' => [
                    [
                        'actions' => ['index','update','create','view'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                    [
                        'actions' => ['import'],
                        'allow' => (!Yii::$app->user->isGuest && Yii::$app->user->identity->USER_TYPE != 'partner')?true:false,
                        'roles' => ['@'],
                    ],
                ],
            ],

            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all PoMaster models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PoMasterSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single PoMaster model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new PoMaster model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new PoMaster();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->PO_ID]);
        } else {
            //var_dump($model->getErrors());exit;
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing PoMaster model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->PO_ID]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing PoMaster model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    /*public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }*/

    /**
     * Finds the PoMaster model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return PoMaster the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = PoMaster::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionImport()
    {
        $model = new ImportPO();
        if ($model->load(Yii::$app->request->post())) {
            $model->CSV = UploadedFile::getInstance($model, 'CSV');
            $ins_record = 0;
            $fl_record = 0;

            if ($model->validate()) {
                $extension = explode('.', $model->CSV->name);
                $ext = end($extension);
                $filename = md5(time() . $model->CSV->name) . '.' . $ext;
                if (($fp = fopen($model->CSV->tempName, "r")) !== false) {
                    $i = 0;
                    while ($data = fgetcsv($fp, 99999)) {
                        $importmodel = new PoMaster();
                        $i++;
                        if ($i == 1) {
                            continue;
                        }

                        $importmodel->MERCHANT_ID = $model->IMPORT_MERCHANT;
                        $importmodel->PARTNER_ID = $model->IMPORT_PARTNER;
                        $importmodel->SAP_REFERENCE = $data[0];
                        $importmodel->PO_NUMBER = trim($data[1]);
                        $importmodel->DATE_OF_CREATION = strtotime(trim($data[2]));
                        $importmodel->AMOUNT = trim($data[3]);

                        if ($importmodel->save()) {
                            $ins_record++;
                        } else {
                            $fl_record++;
                        }
                    }
                    fclose($fp);
                    if(!empty($ins_record)) {
                        Yii::$app->getSession()->setFlash('success', '<div class="alert alert-success">'.$ins_record.' Record(s) inserted successfully.</div>');
                    }
                    if(!empty($fl_record)) {
                        Yii::$app->getSession()->setFlash('error', '<div class="alert alert-danger">'.$fl_record.' Record(s) could not be insert because of the validation error(s).</div>');
                    }
                }  else {
                    Yii::$app->getSession()->setFlash('error', '<div class="alert alert-danger">Error occurred while uploading file to the server.</div>');
                }
            }
        }
        return $this->render('import', [
            'model' => $model,
        ]);

    }
}
