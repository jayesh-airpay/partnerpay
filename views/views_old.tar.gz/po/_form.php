<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\PoMaster */
/* @var $form yii\widgets\ActiveForm */
?>

<?php
$this->registerJs('
    function loadPartnerDropdown(mid) {
        var partner_selected = "'.$model->MERCHANT_ID.'";
        if(mid != "" && mid != 0 && mid != null) {
            var url = "' . \yii\helpers\Url::to(['/user/get-partner-list']) . '";
            var post_data  = "ajax=true&' . Yii::$app->request->csrfParam . '=' . Yii::$app->request->csrfToken . '&mid="+mid+"&selected="+partner_selected;
            console.log(url);
            $.post(url, post_data, function (data) {
                $("#importpo-import_partner").html(data);
            }).fail(function (data) {});
        }
    }
', yii\web\View::POS_READY, 'merchant-function');

$this->registerJs('
$("#importpo-import_merchant").change(function () {
    var merchant_id = $("#importpo-import_merchant").val();
    loadPartnerDropdown(merchant_id);
});

', yii\web\View::POS_READY, 'merchant');
?>

<div class="page-header">
    <h4><?= ($model->isNewRecord)?'Create':'Update' ?> PO</h4>
    <div class="fieldstx">Fields with <span>*</span> are required.</div>
</div>

<div class="po-master-form">

    <?php $form = ActiveForm::begin(['options' => ['enctype'=>'multipart/form-data', 'class'=>'form']]); ?>

    <?php
    if (!Yii::$app->user->isGuest) {
        if (Yii::$app->getUser()->identity->USER_TYPE == 'admin') { ?>
            <div class="row">
                <div class="col-sm-6 col-md-5 col-lg-4">
                    <div class="form-group req">
                        <?= $form->field($model, 'MERCHANT_ID')->dropDownList(\yii\helpers\ArrayHelper::map(\app\models\MerchantMaster::find()->all(), 'MERCHANT_ID', 'MERCHANT_NAME'), ['prompt' => 'Select Merchant'])->label(false) ?>
                    </div>
                </div>
            </div>
            <?php
        }
    }
    ?>

    <?php
    if (!Yii::$app->user->isGuest) {
        if (Yii::$app->getUser()->identity->USER_TYPE != 'partner') { ?>
            <div class="row">
                <div class="col-sm-6 col-md-5 col-lg-4">
                    <div class="form-group req">
                        <?= $form->field($model, 'PARTNER_ID')->dropDownList(\yii\helpers\ArrayHelper::map(\app\models\Partner::find()->all(), 'PARTNER_ID', 'PARTNER_NAME'), ['prompt' => 'Select Partner'])->label(false) ?>
                    </div>
                </div>
            </div>
            <?php
        }
    }
    ?>

    <div class="row">
        <div class="col-sm-6 col-md-5 col-lg-4">
            <div class="form-group req">
                <?= $form->field($model, 'SAP_REFERENCE')->textInput(['maxlength' => true, 'placeholder'=>'SAP Reference'])->label(false) ?>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 col-md-5 col-lg-4">
            <div class="form-group req">
                <?= $form->field($model, 'PO_NUMBER')->textInput(['maxlength' => true, 'placeholder'=>'PO Number'])->label(false) ?>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 col-md-5 col-lg-4">
            <div class="form-group">

                <?= $form->field($model, 'DATE_OF_CREATION')->widget(\yii\jui\DatePicker::className(), [
                    //'language' => 'ru',
                    'dateFormat' => 'yyyy-MM-dd',
                    'options' => ['class' => 'form-control', 'readonly' => 'readonly','placeholder'=>'Date Of Creation'],
                    'clientOptions' => ['class' => 'form-control'],
                    'containerOptions' => ['class' => 'form-control'],

                ])->label(false) ?>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 col-md-5 col-lg-4">
            <div class="form-group req">
                <?= $form->field($model, 'AMOUNT')->textInput(['placeholder'=>'Amount'])->label(false) ?>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 col-md-5 col-lg-4">
            <div class="form-group">
                <?= $form->field($model,'PDF_ATTACHMENT')->fileInput(['title'=>'Select PDF'])->label(false); ?>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 col-md-4">
            <div class="form-group">
                <?= Html::submitButton($model->isNewRecord ? 'Submit' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-primary lg-btn' : 'btn btn-primary lg-btn']) ?>
            </div>
        </div>
    </div>

    <?php ActiveForm::end(); ?>

</div>
