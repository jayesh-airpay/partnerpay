<?php

/* @var $this yii\web\View */

$this->title = 'Partnerpay';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Partnerpay!</h1>

        <p class="lead">Welcome.</p>


    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
               </div>
            <div class="col-lg-4">
                </div>
            <div class="col-lg-4">
               </div>
        </div>

    </div>
</div>
