<?php
/**
 * Created by PhpStorm.
 * User: nandana
 * Date: 11/4/16
 * Time: 3:02 PM
 */





?>
<div class="header navbar-fixed-top">
    <nav id="w1" class="navbar navbar-default" role="navigation">
        <div><div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#w1-collapse"><span class="sr-only">Menu</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span></button><a class="navbar-brand" href="/multiple_partnerpay/web/site/dashboard"><img src="/multiple_partnerpay/web/themes/partnerpay/images/partnerpay-logo.png" alt="Partnerpay"></a>
            </div><div id="w1-collapse" class="container tophead collapse navbar-collapse"><ul id="w2" class="nav navbar-nav navbar-right"><li><a href="/multiple_partnerpay/web/site/dashboard">Home</a></li>
                    <li class="dropdown"><a class="dropdown-toggle" href="#" data-toggle="dropdown">Merchant <b class="caret"></b></a><ul id="w3" class="dropdown-menu"><li class="active"><a href="/multiple_partnerpay/web/merchant/index" tabindex="-1">List Merchant</a></li>
                            <li><a href="/multiple_partnerpay/web/merchant/create" tabindex="-1">Create Merchant</a></li></ul></li>
                    <li class="dropdown"><a class="dropdown-toggle" href="#" data-toggle="dropdown">Partners <b class="caret"></b></a><ul id="w4" class="dropdown-menu"><li><a href="/multiple_partnerpay/web/partner" tabindex="-1">List Partners</a></li>
                            <li><a href="/multiple_partnerpay/web/partner/create" tabindex="-1">Create Partner</a></li></ul></li>
                    <li class="dropdown"><a class="dropdown-toggle" href="#" data-toggle="dropdown">Invoices <b class="caret"></b></a><ul id="w5" class="dropdown-menu"><li><a href="/multiple_partnerpay/web/invoice" tabindex="-1">List Invoices</a></li>
                            <li><a href="/multiple_partnerpay/web/invoice/create" tabindex="-1">Create Invoice</a></li></ul></li>
                    <li class="dropdown"><a class="dropdown-toggle" href="#" data-toggle="dropdown">Users <b class="caret"></b></a><ul id="w6" class="dropdown-menu"><li><a href="/multiple_partnerpay/web/user/index" tabindex="-1">List Users</a></li>
                            <li><a href="/multiple_partnerpay/web/user/create" tabindex="-1">Create User</a></li></ul></li>
                    <li class="userbox dropdown"><a class="dropdown-toggle" href="#" data-toggle="dropdown"><span>admin@airpay.co.in</span><i class="fa fa-user"></i> <b class="caret"></b></a><ul id="w7" class="dropdown-menu"><li><a href="/multiple_partnerpay/web/site/logout" data-method="post" tabindex="-1">Logout</a></li></ul></li></ul></div></div></nav>
</div>

